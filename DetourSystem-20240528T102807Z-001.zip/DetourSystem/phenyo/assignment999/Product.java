  //Main bin
  
   import java.io.*;
   import java.util.*;
   //import java.awt;
   import javax.swing.*;
	
    public class Product {
    
      String name= null; //variable to store in name
      double price=0.0;   //variable to store the price
      int quantity=0;      //variable to store quantity of each product
      //Product p1=new Product();
       public Product (){}
   
   	//Method to set a products information
        //The instance variables are set according
      	//to the parameters
       Product (String name, double price, int quantity){
         this.name=name;
         this.price=price;
         this.quantity=quantity;
      
      }
     
     //array object created
      //ArrayList<Product> array = new ArrayList<Product>();
      ArrayList<Product> array88 = new ArrayList<Product>();
   
       public void setName (String name) {  //set the name using this keyword
         this.name=name;
      }
   
       public void setPrice (double price) { //set the price using this keyword 
         this.price=price;
      }
      
       public void setQuantity (int quanitity) { //set the quantity using this keeyword
         this.quantity=quantity;
      }
     
      
       public String getName (){ //get the name and return it
         return name;
      }
      
       public double getPrice (){ //get the name and return it
         return price;
      }
      
       public int getQuantity (){ //get the quantity and return it
         return quantity;
      }
   
    
   	
       public void Stockcontrol (){
      
         try{ 
            File input= new File("Stockcontrol.txt");
            FileReader fr= new FileReader(input);
            BufferedReader Br= new BufferedReader(fr);
            StringTokenizer stn;
         	
         	// for(int i = 0; i < maxNumberOfProduct; i++)
            // gradeProg.Stockcontrol[i] = new Student();
            String fileLine= Br.readLine();
            
            while(fileLine!=null){
               stn= new StringTokenizer(fileLine," ");
               while(stn.hasMoreTokens()){               //get the number of products
                  System.out.println(stn.nextToken());
                  fileLine=Br.readLine();
               }
            }
         	
            FileWriter fw= new FileWriter("Stockcontrol.txt");
            BufferedWriter bw= new BufferedWriter (fw);
            bw.write ("error");
            bw.close();
         	
         	
            
            
         
                     
          // while(Line!=null){
            
               //System.out.println(Line);
                //Line=Br.readLine();
               
            
         
         
         
         }
             catch(Exception e){
               System.out.println(e);
             
            }
           
            
            
      }   
      		
      /*public array88 Stockcontrol(){
      
         try{
            Scanner sc = new Scanner(new File("Stockcontrol.txt"));
         
         
            while(sc.hasNextLine())	{
            
               String name = sc.next();
               int quantity = sc.nextInt();
               double price = sc.nextDouble();
              
            
               array88.add(new Product(name,price,quantity));
            
               for(Product s :array88){
               
                  double x=s.getPrice();
               
               }
            
            }
         
         }
             catch(Exception e){}
      
      
      
      
         return array88;
      }*/
        
      
      
        
   
   }