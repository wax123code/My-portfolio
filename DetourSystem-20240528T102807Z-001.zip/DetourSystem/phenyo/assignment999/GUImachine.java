import java.awt.*;
import java.awt.event.*;
import javax.swing.*;         //packages used for GUI
import javax.swing.event.*;
import java.util.*;
  // import java.util.ArrayList<Product>;
  //java.util.EventObject)

public class GUImachine extends JPanel implements ActionListener {
   private JButton button1; //creating and declaring of buttons,text areas, labels and textfields
   private JButton button2;
   private JButton button3;
   private JLabel label1;
   private JButton button4;
   private JButton button5;
   private JButton button6;
   private JButton button7;
   private JLabel label2;
   private JTextArea TextArea01;
   private JButton button8;
   private JButton button9;
   private JButton button10;
   private JButton button11;
   private JButton button12;
   private JButton button13;
   private JButton button14;
   private JButton button15;
   private JButton button16;
   private JButton button17;
   private JButton button18;
   private JButton button19;
   private JButton button20;
   private JButton button21;
   private JButton button22;
   private JLabel label3;
   private JTextField textfield1;
   private JButton button23;
   private JLabel label4;
   private JTextField textfield2;
   public ArrayList ls;
   private double Totalcost;
   private double Totalamount;
   private double Change;
    
 
	   
   public GUImachine() {
     //construct components 
      button1 = new JButton ("Coke");  //declaring names for the  buttons
      button1.setIcon (new ImageIcon("coke.jpg")); //selcting images for the button 
      button2 = new JButton ("Fanta");         
      button2.setIcon (new ImageIcon("fanta.jpg"));
      button3 = new JButton ("Fruitgushers");
      button3.setIcon (new ImageIcon("fruitgushers.jpg"));
      label1 = new JLabel ("Phenyo's Vending Machine");
      button4 = new JButton ("Lunchbar");
      button4.setIcon (new ImageIcon("lunchbar.jpg"));
      button5 = new JButton ("Peanuts");
      button5.setIcon (new ImageIcon("peanuts.jpg"));
      button6 = new JButton ("Camel-milkchocolate");
      button6.setIcon (new ImageIcon("camel-milkchocolate.jpg"));
      button7 = new JButton ("Cadbury");
      button7.setIcon (new ImageIcon("cadburychocolate.jpg"));
      label2 = new JLabel ("PRODUCTS"); //declaring names for products label
      TextArea01 = new JTextArea (5, 5);
      button8 = new JButton ("BUY");
      button9 = new JButton ("Remove item");
      button10 = new JButton ("Remove all");
      button11 = new JButton ("5t");
      button12 = new JButton ("10t");
      button13 = new JButton ("25t");
      button14 = new JButton ("50t");
      button15 = new JButton ("1P");
      button16 = new JButton ("2P");
      button17 = new JButton ("5P");
      button18 = new JButton ("50P");
      button19 = new JButton ("10P");
      button20 = new JButton ("20P");
      button21 = new JButton ("100P");
      button22 = new JButton ("200P");
      label3 = new JLabel ("Total");
      textfield1 = new JTextField (5);
      button23 = new JButton ("  ");
      label4 = new JLabel ("Change");
      textfield2 = new JTextField (5);
   
     //adjust size and set layout for GUI
      setSize (new Dimension (831, 511));
      setLayout (null);
   
     //add components
      add (button1);
      add (button2);
      add (button3);   //addition of buttons to the GUI
      add (label1);
      add (button4);
      add (button5);
      add (button6);
      add (button7);
      add (label2);
      add (TextArea01); //adding of text area to the GUI
      add (button8);
      add (button9);
      add (button10);
      add (button11);
      add (button12);
      add (button13);
      add (button14);
      add (button15);
      add (button16);
      add (button17);
      add (button18);
      add (button19);
      add (button20);
      add (button21);
      add (button22);
      add (label3);
      add (textfield1); //adding textfield to GUI
      add (button23);
      add (label4);
      add (textfield2);
   
     //setting bounds for buttons,textfields and textareas
      button1.setBounds (30, 155, 155, 30);
      button2.setBounds (30, 210, 155, 30);
      button3.setBounds (30, 265, 155, 30);
      label1.setBounds (310, 0, 230, 65);
      button4.setBounds (30, 315, 155, 30);
      button5.setBounds (30, 365, 155, 30);
      button6.setBounds (30, 415, 155, 30);
      button7.setBounds (30, 465, 155, 30);
      label2.setBounds (70, 105, 75, 30);
      TextArea01.setBounds (240, 155, 190, 245);
      button8.setBounds (275, 425, 100, 25);
      button9.setBounds (440, 155, 110, 25);
      button10.setBounds (440, 200, 110, 25);
      button11.setBounds (580, 160, 55, 30);
      button12.setBounds (635, 160, 65, 30);
      button13.setBounds (700, 160, 65, 30);
      button14.setBounds (765, 160, 65, 30);
      button15.setBounds (580, 190, 55, 30);
      button16.setBounds (635, 185, 65, 35);
      button17.setBounds (700, 190, 65, 30);
      button18.setBounds (640, 220, 60, 30);
      button19.setBounds (765, 190, 65, 30);
      button20.setBounds (580, 220, 60, 30);
      button21.setBounds (765, 220, 65, 30);
      button22.setBounds (700, 220, 65, 30);
      label3.setBounds (630, 275, 45, 25);
      textfield1.setBounds (690, 275, 100, 25);
      button23.setBounds (640, 310, 150, 30);
      label4.setBounds (625, 360, 55, 25);
      textfield2.setBounds (690, 360, 100, 25);
      
      button1.addActionListener(this);
      button2.addActionListener(this);//action listeners for buttons using this keyword
      button3.addActionListener(this);
      button4.addActionListener(this);
      button5.addActionListener(this);
      button6.addActionListener(this);
      button7.addActionListener(this);
      button8.addActionListener(this);
      button9.addActionListener(this);
      button10.addActionListener(this);
      button11.addActionListener(this);
      button12.addActionListener(this);
      button13.addActionListener(this);
      button14.addActionListener(this);
      button15.addActionListener(this);
      button16.addActionListener(this);
      button17.addActionListener(this);
      button18.addActionListener(this);
      button19.addActionListener(this);
      button20.addActionListener(this);
      button21.addActionListener(this);
      button22.addActionListener(this);         
      button23.addActionListener(this);
   
   
   
   
   
   
   }   
     
   //private class button1Listener1 implements ActionListener{
   
   public void actionPerformed(ActionEvent e){
      	 
      if(e.getSource()==button1){  //get information from the button
         TextArea01.append("Coke: P7.95 \n"); //sets the name and price of button
         this.Totalcost=Totalcost;    //this keyword used to set the Totalcost
         Totalcost +=7.95;          //the totalcost of the button 
         textfield1.setText(String.valueOf(Totalcost)); //setting where the button must print output in GUI
         
      }
      else if(e.getSource()==button2){
         this.Totalcost=Totalcost;
         TextArea01.append("Fanta: P7.95 \n");
         Totalcost +=7.95;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button3){
         TextArea01.append("Fruitgushers: P98.0 \n");
         this.Totalcost=Totalcost;
         Totalcost +=98.0;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button4){
         TextArea01.append("Lunchbar: P6.80 \n");
         this.Totalcost=Totalcost;
         Totalcost +=6.80;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button5){
         TextArea01.append("Peanuts: P2.35 \n");
         this.Totalcost=Totalcost;
         Totalcost +=2.35;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button6){
         TextArea01.append("Camel-milkchocolate: P9.80 \n");
         this.Totalcost=Totalcost;
         Totalcost +=9.80;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button7){
         TextArea01.append("Cadbury: P8.75 \n");
         this.Totalcost=Totalcost;
         Totalcost +=8.75;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button8){
         Change = Totalamount-Totalcost;
         
         textfield2.setText(String.valueOf(Change));
         
      }   
      else if(e.getSource()==button7){
         TextArea01.append("Cadbury: P8.75 \n");
         this.Totalcost=Totalcost;
         Totalcost +=8.75;
         textfield1.setText(String.valueOf(Totalcost));
         
      }
      else if(e.getSource()==button11){
         Totalamount +=0.5;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button12){
         Totalamount +=0.10;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button13){
         Totalamount +=0.25;
         button23.setText(String.valueOf(Totalamount));
      }
      else if(e.getSource()==button14){
         Totalamount +=0.50;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button15){
         Totalamount +=1.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button16){
         Totalamount +=2.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button17){
         Totalamount +=5.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button19){
         Totalamount +=10.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button20){
         Totalamount +=20.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button18){
         Totalamount +=50.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button21){
         Totalamount +=100.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button22){
         Totalamount +=200.0;
         button23.setText(String.valueOf(Totalamount));
         
      }
      else if(e.getSource()==button10){
         TextArea01.setText(null); //setting text so can delete the products
         
                
      }
   }
         
   
   public static void main (String[] args) {
      JFrame frame = new JFrame ("VENDING MACHINE");  //setting name for vending machine 
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE); //setting the frame so it can close 
      frame.getContentPane().add (new GUImachine());   //adding GUI machine to the frame
      frame.pack();   
      frame.setVisible (true); //setting the panel to be seen 
      
   }
   
   
   
   

}