public class Task5 {

public static void main (String [] args) {

int charge= 10; 

switch (charge) {

case 10: System.out.println ("less than 20 checks");
        break;
		  
case 8: System.out.println ("less than 20-39 checks");
        break;	
		  
case 6: System.out.println ("less than 40-59 checks");		
  	     break;
		  
case 4: System.out.println ("less than 60 or more checks");
        break;
		  
default: System.out.println ("Wrong Input");
         break;
			
					  	  
}

}

}