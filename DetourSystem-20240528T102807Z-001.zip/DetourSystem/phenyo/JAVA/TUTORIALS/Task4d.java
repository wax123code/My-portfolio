public class Task4d {

public static void main (String [] args) {

int a= -90;

if (a<10); {
System.out.println("b=0 && c=1"); 
}else if { 
System.out.println("b=-99 && c=0");
}

}

}