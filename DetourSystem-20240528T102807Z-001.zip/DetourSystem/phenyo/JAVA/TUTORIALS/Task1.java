    public class Task1 {
   
       public static void main (String args[]) {
      
      int testscore;xdh
      testscore =70;
      
      if(testscore >= 70) {
      System.out.println("Grade=A");
      }else if (testscore>=40 && testscore<=70){
      System.out.println("Grade=B");
      }else {
      System.out.println("Grade=C");
      }
      
      
      }
   
   
   
   }