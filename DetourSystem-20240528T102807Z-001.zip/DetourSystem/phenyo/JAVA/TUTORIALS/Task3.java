    public class Task3 {
   
       public static void main (String [] args){
      
      int testScore=30;
      //String testScore;
      
      switch (testScore){
      
      case 10: testScore= 10;
              System.out.println("grade = A");
      		  break;
      		  
      case 20: testScore= 20;
      		  System.out.println("grade = B");
      		  break;
      		  		  
      case 30: testScore= 30;
              System.out.println("grade = C");
      		  break;
      		  
      case 40: testScore= 40;
              System.out.println("grade = D");
      		  break;
      		  
      case 50: testScore= 50;
              System.out.println("grade = E");
      		  break;
      		  
      case 60: testScore= 60;
              System.out.println("grade = F");
      		  break;
      		  
      case 70: testScore= 70;
              System.out.println("grade = G");
      		  break; 
      		  
      case 80: testScore= 80;
              System.out.println("grade = H");
      		  break;
      		  
      case 90: testScore= 90;
              System.out.println("grade = I");
      		  break;
      		  
      case 100: testScore= 100;
              System.out.println("grade = J");
      		  break;
      		
      			
      default: System.out.println("Invalid testScore");
               break;
      }
      
      
      
      }
   
   
   }