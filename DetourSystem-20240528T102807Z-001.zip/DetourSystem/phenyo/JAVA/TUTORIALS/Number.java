public class Number {


  Static Scanner scan = new Scanner(System.in);
    public static void main(String [] args)
    {
      System.out.print("Please enter a number to square: ");
        int num = in.nextInt();
        System.out.println("Your number squared is: " + square(num));
    }
    public static int square(int num) 
    {
        return num * num;
    }
}