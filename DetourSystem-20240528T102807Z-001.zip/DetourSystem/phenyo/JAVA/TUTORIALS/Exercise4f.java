    public class Exercise4f {
   
       public static void main (String [] args)
      {
         int sum=0;
         int i=0;
      
         while(i<6) 
         {
         
            sum = sum + i;
            i++;
         
         }
      
      System.out.println("sum is: " +sum);
      
      }
   
   }