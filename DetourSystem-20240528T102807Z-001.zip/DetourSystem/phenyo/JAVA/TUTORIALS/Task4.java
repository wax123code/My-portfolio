    public class Task4 {
   
       public static void main (String [] args) {
      
         int x=12;
         
      	if (x>100) {
      	System.out.println("y= 20");
       	} else 
         System.out.println("x= 0");
      	
      
      
      
      
      }
   
   
   }