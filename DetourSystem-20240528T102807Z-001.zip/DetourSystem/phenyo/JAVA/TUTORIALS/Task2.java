    public class Task2 {
    
       public static void main (String args[]){
       
       
       char grade;
       int testscore=30;
       
       if (testscore>=70){
       grade = 'A';
       } else if (testscore>=40 && testscore<=70)
       grade = 'B';
       else {
       grade = 'C';
       }
       System.out.println("Grade =" + grade);
      
      
      
      
      }
    
    
   }