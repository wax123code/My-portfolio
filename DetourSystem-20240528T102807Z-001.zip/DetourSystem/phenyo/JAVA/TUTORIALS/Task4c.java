public class Task4c {

public static void main (String [] args) {

int sales = 3000000;

if (sales >= 500000.0) {
System.out.println("commission= +0.2");
} else {
System.out.println("commission= +0.1");

}


}

}