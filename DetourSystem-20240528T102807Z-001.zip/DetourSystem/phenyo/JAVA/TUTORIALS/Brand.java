    public class Brand {
   
       public static void main (String args[]){
      
      for(int x=0;x<100;x++) {
      
      System.out.println("*********\n"
                        +"*       *\n"
      						+"*       *\n"
      						+"*********\n");
      
      }
      
      
      
      }
   
   
   }