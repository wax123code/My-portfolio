public class Task4b {

public static void main (String [] args) {

int y= 20;

if (y==100) {
System.out.println ("x=" +1);
} else {
System.out.println ("x=" +0);
}




}


}