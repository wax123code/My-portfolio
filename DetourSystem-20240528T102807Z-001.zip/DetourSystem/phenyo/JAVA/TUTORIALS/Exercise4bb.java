public class Exercise4bb {

public static void main (String args []) {

int age = 20;

while (age < 30) {

System.out.println("age is: " + age);

age++;


}



}

}