import javax.swing.JFrame;
import javax.swing.JPanel;
public class Btn {

public Btn() {

JFrame f = new JFrame();
JPanel p = new Jpanel();






}
}
public static void main(String [] args){
new Btn();
}