public class product2{

product p1= new product ("coke",7.95,10);









}