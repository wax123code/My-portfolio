   import java.util.Scanner;

    public class VendingMachine{
   
      
         static String Name1= "coke";
         static double Price1= 7.95;
         static int Quantity1= 10;
      
         static String Name2= "fanta";
         static double Price2= 8.20;
         static int Quantity2= 10;
      
         static String Name3= "fruit gushers";
         static double Price3= 98.0;
         static int Quantity3= 6;
      
         static String Name4= "lunch bar";
         static double Price4= 6.80;
         static int Quantity4= 10;
      
         static String Name5= "peanuts";
         static double Price5= 2.35;
         static int Quantity5= 20;
      
         static String Name6= "camel-milk chocolate";
         static double Price6= 9.80;
         static int Quantity6= 7;
      
         static String Name7= "cadbury chocolate";
         static double Price7= 8.75;
         static int Quantity7= 15;
      
      static double total= double price * int quantity;
      
      
      public static void main(String [] args){
      
      VendingMachine p1= new VendingMachine(Name1,Price1,Quantity1);
      
      System.out.println("coke cost P" +p1.getPrice1());
      System.out.println("Enter Quantity");
      Scanner sc=new Scanner (System.in);
      Quantity=sc.nextInt();
      
      
      
      
      
      
      }
   
   }