   import javax.swing.*;
   import java.awt.*;
   import javax.swing.ImageIcon;
   //import java.awt.GridBagLayout;
	//import java.awt.GridBagConstraints;	


//Gui components
        //Each of the items to be displayed needs a label and textfield.
        //Labels end with label1
    public class GUI {
   
      private JFrame f;
      private JPanel panel1;
      private JPanel panel2;
      private JPanel panel3;
      private JPanel panel4;
      private JPanel panel5;
      private JButton B1;
      private JLabel lb;
   
      private JButton b1;
      private JButton b2;
      private JButton b3;
      private JButton b4;
      private JButton b5;
      private JButton b6;
      private JButton b7;
      private JButton b8;
      private JButton b9;  
   
       public static void main(String args []){
      
      
      
         JFrame f= new JFrame();
      
         GUI gu = new GUI();
         gu.GraphicalUI();
      
         Product p1 = new Product();
         Product p2 = new Product();
         Product p3 = new Product();
         Product p4 = new Product();
         Product p5 = new Product();
         Product p6 = new Product();
         Product p7 = new Product();
         p1.Stockcontrol();
      
      }
      
       public void GraphicalUI(){
      
      
         f = new JFrame("Vending Machine");
         f.setSize(600, 800);
         f.setVisible(true);
         f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         f.setLayout(null);	
      	      
         JPanel panel1 = new JPanel();
         panel1.setBackground(Color.BLUE);
         panel1.setSize(200, 1000);
         f.add(panel1,BorderLayout.WEST);
         panel1.setVisible(true);
         
         JPanel panel2= new JPanel();
         panel2.setBackground(Color.GREEN);
         panel2.setSize(400, 400);
        f.add(panel2,BorderLayout.NORTH);
         panel2.setVisible(true);

      	
         b1= new JButton("coke");
         b1.setVisible(true);
         lb= new JLabel("This is coke label");
         panel1.add(b1);
         panel1.add(lb);
         b2= new JButton("fanta");
         lb= new JLabel("This is fanta label");
         panel1.add(b2);
         panel1.add(lb);
         b3= new JButton("fruitgushers");
         lb= new JLabel("This is fruitgushers label");
         panel1.add(b3);
         panel1.add(lb);
         b4= new JButton("lunchbar");
         lb= new JLabel("This is lunchbar label");
         panel1.add(b4);
         panel1.add(lb);
         b5= new JButton("peanuts");
         lb= new JLabel("This is peanuts label");
         panel1.add(b5);
         panel1.add(lb);
         b6= new JButton("camel-milkchocolate");
         lb= new JLabel("This is camel-milkchocolate label");
         panel1.add(b6);
         panel1.add(lb);
         b7= new JButton("cadburychocolate");
         lb= new JLabel("This is cadburychocolate label");
         panel1.add(b7);
         panel1.add(lb);
         b8= new JButton("next");
         panel1.add(b8);
         b9= new JButton("cancel");
         panel1.add(b9); 
      	
      	
         b1.setIcon (new ImageIcon("coke.jpg"));     
         b2.setIcon (new ImageIcon("fanta.jpg"));
         b3.setIcon (new ImageIcon("fruitgushers.jpg")); 
         b4.setIcon (new ImageIcon("lunchbar.jpg"));      
         b5.setIcon (new ImageIcon("peanuts.jpg"));      
         b6.setIcon (new ImageIcon("camel-milkchocolate.jpg"));
         b7.setIcon (new ImageIcon("cadburychocolate.jpg"));
         
      
      	
        /* JPanel panel2= new JPanel();
         panel2.setBackground(Color.GREEN);
         panel2.setSize(100, 800);
      	panel2.setVisible(true);
      	 f.add(panel2,BorderLayout.NORTH);
         
         /*JPanel panel3= new JPanel();
         panel3.setBackground(Color.BLACK);
         panel3.setSize(100, 600);
      	
      	  
         JPanel panel4= new JPanel();
         panel4.setBackground(Color.YELLOW);
         panel4.setSize(100, 50);
      	
      	  
         JPanel panel5= new JPanel();
         panel5.setBackground(Color.GREEN);
         panel5.setSize(100, 100);
         f.add(panel5,BorderLayout.CENTER);
      	      	
         f.add(panel2,BorderLayout.SOUTH);
         f.add(panel3,BorderLayout.WEST);
         f.add(panel4,BorderLayout.EAST);
         f.add(panel5,BorderLayout.NORTH);*/
      
              
      
      	 
      
         //f.add(panel1,BorderLayout.CENTER);
         //b1.setBounds(500, 150, 100, 20);
         //b2.setBounds(500, 155, 100, 20);
         //b3.setBounds(520, 160, 120, 20);
         //b4.setBounds(520, 165, 130, 20);
         //b5.setBounds(540, 170, 140, 20);
         //b6.setBounds(550, 175, 150, 20);
         //b7.setBounds(560, 180, 160, 20);
      
      
      }
   
   
   }