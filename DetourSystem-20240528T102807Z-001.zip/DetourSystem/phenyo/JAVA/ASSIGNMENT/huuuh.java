file reading
	StringTokenizer ts;
				String fileLine= Br.nextLine();
				
				while(Br.hasNext()){
				
				ts = new StringTokenizer(fileLine, " ");
				
				while(ts.hasMoreTokens()){
				System.out.println(ts.nextToken()); //objects
				}
				fileLine= Br.nextLine();
				
				}


https://www.youtube.com/watch?v=Db3cC5iPrOM