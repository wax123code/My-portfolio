GridBagConstraints gbcc = new GridBagConstraints
      	
      		
         setLayout (new GridBagLayout());		
         gbcc.gridx= 0;
      	gbcc.gridy= 0;
         p.add(b1,gbcc);
      	
      	gbcc.gridx= 1;
      	gbcc.gridy= 1;
         p.add(b2,gbcc);
      	
      	gbcc.gridx= 2;
      	gbcc.gridy= 2;
         p.add(b3,gbcc);
      	
      	gbcc.gridx= 3;
      	gbcc.gridy= 3;
         p.add(b4,gbcc);
      	
      	gbcc.gridx= 4;
      	gbcc.gridy= 4;
         p.add(b5,gbcc);
      	
      	gbcc.gridx= 5;
      	gbcc.gridy= 5;
         p.add(b6,gbcc);
      	
      	gbcc.gridx= 6;
      	gbcc.gridy= 6;
         p.add(b7,gbcc);
      	




 GridBagConstraints gbc= new GridBagConstraints();
         
         gbc.insets= new Insets(20,20,20,20);
         gbc.gridx=0;
         gbc.gridy=1;
      	
         panel1.add(button1,gbc);
         gbc.gridx=0;
         gbc.gridx=1;
         
         panel1.add(button2,gbc);
         gbc.gridx=0;
         gbc.gridx=3;
         
         panel1.add(button3,gbc);
         gbc.gridx=0;
         gbc.gridx=4;  
      	
         panel1.add(button4,gbc);
         gbc.gridx=0;
         gbc.gridx=5;  
      	
         panel1.add(button5,gbc);
         gbc.gridx=0;
         gbc.gridx=6;
         
         panel1.add(button6,gbc);
         gbc.gridx=0;
         gbc.gridx=7;
         
         panel1.add(button7,gbc);
         gbc.gridx=0;
         gbc.gridx=8;
      	
         frame.add(panel1,BorderLayout.WEST);
         
         JPanel panel2= new JPanel();
         JPanel panel3= new JPanel();
         JPanel panel4= new JPanel();
         JPanel panel5= new JPanel();
      
