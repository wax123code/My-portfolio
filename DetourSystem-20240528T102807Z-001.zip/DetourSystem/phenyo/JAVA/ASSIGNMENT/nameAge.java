   import java.io.*;
   import java.util.*;
    public class nameAge
   {
       public static void main(String[] args) throws FileNotFoundException
      {
      
         ArrayList<String> names = new ArrayList<String>();
         ArrayList<Integer> ages = new ArrayList<Integer>(); 
         Scanner inFile = new Scanner(new File("stuff.txt"));  
         if(names.size() != ages.size()){
            System.out.println("Something wen't wrong - the number of names and ages are not equal.");
         } 
         else{
            for(int i = 0; i < names.size(); i++){
               System.out.println(names.get(i) + " " + ages.get(i));
            }
         }
      }
   }