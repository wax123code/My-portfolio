   import javax.swing.*;
   import java.awt.*;

    public class test{
   
       public static void main(String args []){
      
         JFrame frame= new JFrame();
         frame.setVisible(true);
         frame.setSize(600, 400);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.setLayout(null);
      
         JPanel panel1= new JPanel(new GridBagLayout());
         
         JButton button1= new JButton("coke");
         JButton button2= new JButton("fanta");
         JButton button3= new JButton("fruitgushers");
         JButton button4= new JButton("lunchbar");
         JButton button5= new JButton("peanuts");
         JButton button6= new JButton("camel-milkchocolate");
         JButton button7= new JButton("cadbury chocolate");
         
         button1.setBounds(100,50,150,30);
         button2.setBounds(100,150,150,30);
         button3.setBounds(100,200,150,30);
         button4.setBounds(100,250,150,30);
         button5.setBounds(100,300,150,30);
         button6.setBounds(100,350,150,30);
         button7.setBounds(100,400,150,30);
      
         GridBagConstraints gbc= new GridBagConstraints();
         
         gbc.insets= new Insets(20,20,20,20);
         gbc.gridx=0;
         gbc.gridy=1;
      	
         panel1.add(button1,gbc);
         gbc.gridx=0;
         gbc.gridx=1;
         
         panel1.add(button2,gbc);
         gbc.gridx=0;
         gbc.gridx=3;
         
         panel1.add(button3,gbc);
         gbc.gridx=0;
         gbc.gridx=4;  
      	
         panel1.add(button4,gbc);
         gbc.gridx=0;
         gbc.gridx=5;  
      	
         panel1.add(button5,gbc);
         gbc.gridx=0;
         gbc.gridx=6;
         
         panel1.add(button6,gbc);
         gbc.gridx=0;
         gbc.gridx=7;
         
         panel1.add(button7,gbc);
         gbc.gridx=0;
         gbc.gridx=8;
      	
         frame.add(panel1,BorderLayout.WEST);
         
         JPanel panel2= new JPanel();
         JPanel panel3= new JPanel();
         JPanel panel4= new JPanel();
         JPanel panel5= new JPanel();
      
      
      }
   
   }