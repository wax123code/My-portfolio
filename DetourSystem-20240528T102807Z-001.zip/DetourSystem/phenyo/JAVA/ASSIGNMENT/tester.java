    public class tester{
	
   
       public static void main (String args []){
       
         new GUImachine();
         //GUI.setVisible(true);
      
     /*  Product p1=new Product();   //object for creating product p1
         p1.setName("coke");
         p1.setPrice(7.95);         //use of mutators for name,price,quantity
         p1.setQuantity(10);
      
         Product p2=new Product();
         p2.setName("fanta");
         p2.setPrice(8.20);
         p2.setQuantity(10);
      
         Product p3=new Product();
         p3.setName("fruitgushers");
         p3.setPrice(98.0);
         p3.setQuantity(6);
      
         Product p4=new Product();
         p4.setName("lunchbar");
         p4.setPrice(6.80);
         p4.setQuantity(10);
      
         Product p5=new Product();
         p5.setName("peanuts");
         p5.setPrice(2.35);
         p5.setQuantity(10);
      
         Product p6=new Product();
         p6.setName("camel-milkchocolate");
         p6.setPrice(9.80);
         p6.setQuantity(7);
      
         Product p7=new Product(); 
         p7.setName("cadburychocolate");
         p7.setPrice(8.75);
         p7.setQuantity(15); */
			
      Product p1=new Product();
         p1.Stockcontrol();        //called method to access the text file
      	
			array88();
      	         
      
      
      //System.out.println(p1.Stockcontrol);
      }
   
   }
