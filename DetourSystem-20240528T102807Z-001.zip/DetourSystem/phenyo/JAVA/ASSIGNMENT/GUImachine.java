   import java.awt.*;
   import java.awt.event.*;
   import javax.swing.*;
   import javax.swing.event.*;
   import java.util.*;
  // import java.util.ArrayList<Product>;
  //java.util.EventObject)

    public class GUImachine extends JPanel {
      private JButton button1;
      private JButton button2;
      private JButton button3;
      private JLabel label1;
      private JButton button4;
      private JButton button5;
      private JButton button6;
      private JButton button7;
      private JLabel label2;
      private JTextArea TextArea01;
      private JButton button8;
      private JButton button9;
      private JButton button10;
      private JButton button11;
      private JButton button12;
      private JButton button13;
      private JButton button14;
      private JButton button15;
      private JButton button16;
      private JButton button17;
      private JButton button18;
      private JButton button19;
      private JButton button20;
      private JButton button21;
      private JButton button22;
      private JLabel label3;
      private JTextField textfield1;
      private JButton button23;
      private JLabel label4;
      private JTextField textfield2;
      public ArrayList ls;
    
    
   	   
       public GUImachine() {
        //construct components
         button1 = new JButton ("Coke");
         button2 = new JButton ("Fanta");
         button3 = new JButton ("Fruitgushers");
         label1 = new JLabel ("Phenyo's Vending Machine");
         button4 = new JButton ("Lunchbar");
         button5 = new JButton ("Peanuts");
         button6 = new JButton ("Camel-milkchocolate");
         button7 = new JButton ("Cadbury");
         label2 = new JLabel ("PRODUCTS");
         TextArea01 = new JTextArea (5, 5);
         button8 = new JButton ("BUY");
         button9 = new JButton ("Remove item");
         button10 = new JButton ("Remove all");
         button11 = new JButton ("5t");
         button12 = new JButton ("10t");
         button13 = new JButton ("25t");
         button14 = new JButton ("50t");
         button15 = new JButton ("1P");
         button16 = new JButton ("2P");
         button17 = new JButton ("5P");
         button18 = new JButton ("50P");
         button19 = new JButton ("10P");
         button20 = new JButton ("20P");
         button21 = new JButton ("200P");
         button22 = new JButton ("100P");
         label3 = new JLabel ("Total ");
         textfield1 = new JTextField (5);
         button23 = new JButton ("Pay");
         label4 = new JLabel ("Change");
         textfield2 = new JTextField (5);
      
        //adjust size and set layout
         setSize (new Dimension (831, 511));
         setLayout (null);
      
        //add components
         add (button1);
         add (button2);
         add (button3);
         add (label1);
         add (button4);
         add (button5);
         add (button6);
         add (button7);
         add (label2);
         add (TextArea01);
         add (button8);
         add (button9);
         add (button10);
         add (button11);
         add (button12);
         add (button13);
         add (button14);
         add (button15);
         add (button16);
         add (button17);
         add (button18);
         add (button19);
         add (button20);
         add (button21);
         add (button22);
         add (label3);
         add (textfield1);
         add (button23);
         add (label4);
         add (textfield2);
      
        //set component bounds (only needed by Absolute Positioning)
         button1.setBounds (30, 155, 155, 30);
         button2.setBounds (30, 210, 155, 30);
         button3.setBounds (30, 265, 155, 30);
         label1.setBounds (310, 0, 230, 65);
         button4.setBounds (30, 315, 155, 30);
         button5.setBounds (30, 365, 155, 30);
         button6.setBounds (30, 415, 155, 30);
         button7.setBounds (30, 465, 155, 30);
         label2.setBounds (70, 105, 75, 30);
         TextArea01.setBounds (240, 155, 190, 245);
         button8.setBounds (275, 425, 100, 25);
         button9.setBounds (440, 155, 110, 25);
         button10.setBounds (440, 200, 110, 25);
         button11.setBounds (580, 160, 55, 30);
         button12.setBounds (635, 160, 65, 30);
         button13.setBounds (700, 160, 65, 30);
         button14.setBounds (765, 160, 65, 30);
         button15.setBounds (580, 190, 55, 30);
         button16.setBounds (635, 185, 65, 35);
         button17.setBounds (700, 190, 65, 30);
         button18.setBounds (640, 220, 60, 30);
         button19.setBounds (765, 190, 65, 30);
         button20.setBounds (580, 220, 60, 30);
         button21.setBounds (765, 220, 65, 30);
         button22.setBounds (700, 220, 65, 30);
         label3.setBounds (630, 275, 45, 25);
         textfield1.setBounds (690, 275, 100, 25);
         button23.setBounds (640, 310, 150, 30);
         label4.setBounds (625, 360, 55, 25);
         textfield2.setBounds (690, 360, 100, 25);
         
         button1.addActionListener(new button1Listener1());
         button2.addActionListener(new button2Listener2());
         button3.addActionListener(new button3Listener3());
         button4.addActionListener(new button4Listener4());
         button5.addActionListener(new button5Listener5());
         button6.addActionListener(new button6Listener6());
         button7.addActionListener(new button7Listener7()); 
         button8.addActionListener(new button1Listener1());
         button9.addActionListener(new button1Listener1());
         button10.addActionListener(new button1Listener1());
         button11.addActionListener(new button1Listener1());
         button12.addActionListener(new button1Listener1());
         button13.addActionListener(new button1Listener1());
         button14.addActionListener(new button1Listener1());
         button15.addActionListener(new button1Listener1());
         button16.addActionListener(new button1Listener1());
         button17.addActionListener(new button1Listener1());
         button18.addActionListener(new button1Listener1());
         button19.addActionListener(new button1Listener1());
         button20.addActionListener(new button1Listener1());
         button21.addActionListener(new button1Listener1());
         button22.addActionListener(new button1Listener1());
         button23.addActionListener(new button1Listener1());
      
      //addElement(name, quantity, price);
      
      
      
      
      }   
        
       private class button1Listener1 implements ActionListener{
      
          public void actionPerformed(ActionEvent e){
          //if { (rs.next)
            TextArea01.setText("Coke 7.95 10\n");
				 
            //FileWriter fw= new FileWriter("Stockcontrol.txt");
         
         	
                            	        
         	 /*
         //if (e.getSource() == button1){      
            ArrayList<Product> array88 = new ArrayList<Product>();
         
         
            Product p1= new Product();
            array88 = p1.Stockcontrol();
            String f;
            for(Product p1 : array88){
               //if("coke".equals(p1.getName()))
               
               //{
               
               TextArea01.setText("Black"+" "+"4.55"+" "+"20");
               System.out.println();
                 //addElement(p1.getName()+" "+p1.getQuantity()+" "+p1.getPrice());
            }
            
         } */
         
         }
      }
      
       private class button2Listener2 implements ActionListener{
         	
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\nFanta 7.95 10\n");
         	
         }
      }
       private class button3Listener3 implements ActionListener{
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\nFruitgushers 98.0 6\n");
         
         }
      }  
       private class button4Listener4 implements ActionListener{
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\nLunchbar 6.80 10\n");
         
         }
      }  
       private class button5Listener5 implements ActionListener{
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\nPeanuts 2.35 10\n");
         
         }
      }  
   
       private class button6Listener6 implements ActionListener{
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\nCamel-milkchocolate 9.80 7");
         
         }
      }  
       private class button7Listener7 implements ActionListener{
          public void actionPerformed(ActionEvent e) {
            TextArea01.setText("\ncadburychocolate 8.75 15");
         
         }
      }  
   
      
       public static void main (String[] args) {
         JFrame frame = new JFrame ("VENDING MACHINE");
         frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
         frame.getContentPane().add (new GUImachine());
         frame.pack();
         frame.setVisible (true);
      
      }
   
      
   }
      
   
