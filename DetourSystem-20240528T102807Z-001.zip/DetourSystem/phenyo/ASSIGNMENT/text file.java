import Java.io*;
   public static void main (String args[]){
     try{
     FileInputstream fileobject=new Fileinput("9.80.txt",7..95
