import java.util.Scanner;
import java.util.*;

public class VendingMach 
{
   static double price ;
   public static void main(String [] arg)
   {
      System.out.println("=========== Drinks===========");
      System.out.println("1.Coke BWP 7.95\n" +
                    "2.Fanta BWP 8.95  ");
                    
      System.out.println("============snack============");
      System.out.println("3.fruit gushers BWP 98.00\n" +
                    "4.chips BWP 7.95");
      
      System.out.println("============chocolates=======");
      System.out.println("5.camel-mlk chocolate\n "+
                    "6 dark chocolate BWP 11.95");
      
      
      System.out.println("Enter money");
      Scanner scn = new Scanner(System.in);
      price = scn.nextDouble();
      System.out.println("\n Choose your item");
      Scanner sc = new Scanner(System.in);
    
      double change;
      int choice = sc.nextInt();
      switch(choice){
      
         case 1:
            System.out.println("Coke");
            change = price - 7.95;
            System.out.println("Your change is " + change);
            break;
            
         case 2:
            System.out.println("Fanta");
            change = price - 8.95;
            System.out.println("Your change is"+ change);
            break;
            
         case 3:
            System.out.println("chips");
            change=price-7.95;
            System.out.println("Your change is"+change);
            break; 
            
         default:
            System.out.print("Error!!.... Choose option 1 or 2");
            break;
      
      }
   
   }
}