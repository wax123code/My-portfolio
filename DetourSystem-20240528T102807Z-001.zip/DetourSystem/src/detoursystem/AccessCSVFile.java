/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package detoursystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class AccessCSVFile {
    
    //Fields:
    private static final String FILE_NAME = "employees.txt";
    private Scanner input;
    private File file;
    private String[] row;
    private Employee temp;
    
    private ArrayList <Employee> employeeList = new ArrayList<>();
    
    public void openFile() 
    {
        try {
            //Get the input file instance:
            file = new File(FILE_NAME);
            //Use Scanner to read file:
            input = new Scanner(file);
	} 
	catch (Exception e) {
		e.printStackTrace();
	} 
    }
    
    public ArrayList<Employee> makeEmployeeArray() throws IOException 
    {  
        
        while (input.hasNext()) { 
            
            String data = input.nextLine(); //Read row
            String[] row = data.split(","); //Specify separator
            
            temp = convertRowToObject(row);
            
            //Populate array with Employee object row:
            this.employeeList.add(temp);
        }
        return this.employeeList;
    }
    
    public Employee convertRowToObject(String[] row) {
        
        this.row = row;
        
        for(int i=1;i<this.row.length;i++) {
            //Get data:
            String department = this.row[8];
            String id = this.row[0];
            
            /**
             * empId[0],empName[1],empSurname[2],empGender[3],empDob[4],
             * empAddress[5],city[6],empTitle[7],empHireDate[8],department[9],
             * empHoursWorked[10],empPayRate[11],empLeaveDays[12],empGratuity[13],
             * empCarAllowPercent[14]
             */
            if(department.equals("Accounts")){ //
                temp = new Accounts(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Human Resources")) {
                temp = new HumanResources(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Management")) {
                temp = new Management(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Marketing")) {
                temp = new Marketing(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Support")) {
                temp = new Support(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else {
                temp = new Temporary(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }
        }
        return temp;
    }
    
    public void closeFile() throws IOException {input.close();}
   
    
}
