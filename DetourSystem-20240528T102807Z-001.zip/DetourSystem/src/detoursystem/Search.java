/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package detoursystem;

import java.util.ArrayList;

/**
 *
 * @author Admin
 */
public class Search {
    
    private ArrayList<Employee> searchResults;
    
    public ArrayList<Employee> searchGender(char gender, ArrayList<Employee> fullList, ArrayList<Employee> results)
    {
        searchResults = new ArrayList<>();
        
        for(Employee emp:fullList)
        {
            if(emp.getEmpGender()==gender)
            {
                this.searchResults.add(emp);
            }
        }
        
        return this.searchResults;
    }
    
    public ArrayList<Employee> searchCity(String city, ArrayList<Employee> fullList, ArrayList<Employee> results)
    {
        searchResults = new ArrayList<>();
        
        for(Employee emp:fullList)
        {
            if(emp.getCity().equals(city))
            {
                this.searchResults.add(emp);
            }
        }
        
        return this.searchResults;
    }
    
}
