/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package detoursystem;

/**
 *
 * @author Admin
 */
public class Management extends Employee {

    /**
     * Object constructor (Superclass constructor called):
     * @param empId
     * @param empName
     * @param empSurname
     * @param empGender
     * @param empDob
     * @param empAddress
     * @param city
     * @param empTitle
     * @param empHireDate
     * @param department
     * @param empHoursWorked
     * @param empPayRate
     * @param empLeaveDays
     * @param empGratuity 
     */
    public Management(String empId, String empName, String empSurname, char empGender, String empDob, String empAddress, String city, String empTitle, String empHireDate, String department, int empHoursWorked, double empPayRate, int empLeaveDays, double empGratuity, double empCarAllowance) {
        super(empId, empName, empSurname, empGender, empDob, empAddress, city, empTitle, empHireDate, department, empHoursWorked, empPayRate, empLeaveDays, empGratuity, empCarAllowance);
    }

    @Override
    public double calculatCarAllowance() {return this.empCarAllowance * this.empHoursWorked * this.empPayRate;}

    @Override
    public double calculateGrossSalary() {return (1 + this.empCarAllowance) * this.empHoursWorked * this.empPayRate;}

    @Override
    public double calculateNetSalary() {return ((1 + this.empCarAllowance) * this.empHoursWorked * this.empLeaveDays) * (1 - Employee.TAX_RATE);}
    
}
