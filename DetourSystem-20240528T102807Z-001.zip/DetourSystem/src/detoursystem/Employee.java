/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package detoursystem;

/**
 *
 * @author Admin
 */
public abstract class Employee {

    protected String empId;
    protected String empName;
    protected String empSurname;
    protected char empGender;
    protected String empDob;
    protected String empAddress;
    protected String city;
    protected String empTitle;
    protected String empHireDate;
    protected String department;
    protected int empHoursWorked;
    protected double empPayRate;
    protected int empLeaveDays;
    protected double empGratuity;
    protected double empCarAllowance;
    protected static final double TAX_RATE = 0.15;
    
    /**
     * Object constructor (Never Called because class is abstract):
     * @param empId
     * @param empName
     * @param empSurname
     * @param empGender
     * @param empDob
     * @param empAddress
     * @param city
     * @param empTitle
     * @param empHireDate
     * @param department
     * @param empHoursWorked
     * @param empPayRate
     * @param empLeaveDays
     * @param empGratuity 
     */
    public Employee(String empId, String empName, String empSurname, char empGender, String empDob, String empAddress, String city,String empTitle, String empHireDate, String department,int empHoursWorked, double empPayRate, int empLeaveDays, double empGratuity, double empCarAllowance) {
        this.empId = empId;
        this.empName = empName;
        this.empSurname = empSurname;
        this.empGender = empGender;
        this.empDob = empDob;
        this.empAddress = empAddress;
        this.city = city;
        this.empTitle = empTitle;
        this.empHireDate = empHireDate;
        this.department= department;
        this.empHoursWorked = empHoursWorked;
        this.empPayRate = empPayRate;
        this.empLeaveDays = empLeaveDays;
        this.empGratuity = empGratuity;
        this.empCarAllowance = empCarAllowance;
    }

    /**
     * Getter Methods:
     * @return attributes
     */
    public String getEmpId() {return empId;}
    public String getEmpName() {return empName;}
    public String getEmpSurname() {return empSurname;}
    public String getDepartment() {return department;}
    public char getEmpGender() {return empGender;}
    public String getEmpDob() {return empDob;}
    public String getEmpAddress() {return empAddress;}
    public String getCity() {return city;}
    public String getEmpTitle() {return empTitle;}
    public String getEmpHireDate() {return empHireDate;}
    public int getEmpHoursWorked() {return empHoursWorked;}
    public double getEmpPayRate() {return empPayRate;}
    public double getEmpCarAllowance() {return empCarAllowance;}
    public int getEmpLeaveDays() {return empLeaveDays;}
    public double getEmpGratuity() {return empGratuity;}
    public static double getTAX_RATE() {return TAX_RATE;}

    /**
     * Setter methods
     * @param empId 
     */
    public void setEmpId(String empId) {this.empId = empId;}
    public void setEmpName(String empName) {this.empName = empName;}
    public void setEmpSurname(String empSurname) {this.empSurname = empSurname;}
    public void setEmpGender(char empGender) {this.empGender = empGender;}
    public void setEmpDob(String empDob) {this.empDob = empDob;}
    public void setEmpAddress(String empAddress) {this.empAddress = empAddress;}
    public void setEmpTitle(String empTitle) {this.empTitle = empTitle;}
    public void setEmpHireDate(String empHireDate) {this.empHireDate = empHireDate;}
    public void setEmpHoursWorked(int empHoursWorked) {this.empHoursWorked = empHoursWorked;}
    public void setEmpPayRate(double empPayRate) {this.empPayRate = empPayRate;}
    public void setEmpLeaveDays(int empLeaveDays) {this.empLeaveDays = empLeaveDays;}
    public void setEmpGratuity(double empGratuity) {this.empGratuity = empGratuity;}
    
    /**
     * Abstract methods to override:
     * @return 
     */
    public abstract double calculatCarAllowance();
    
    public double calculateGrossSalary() {return (1 + this.empCarAllowance) * this.empHoursWorked * this.empPayRate;}
    
    public double calculateNetSalary() {return ((1 + this.empCarAllowance) * this.empHoursWorked * this.empLeaveDays) * (1 - Employee.TAX_RATE);}
    
    
    
    
    
}
