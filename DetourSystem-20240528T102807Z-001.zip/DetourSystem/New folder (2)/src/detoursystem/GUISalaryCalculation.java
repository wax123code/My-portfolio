package detoursystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Author Fcse18-010
 */
public class GUISalaryCalculation extends javax.swing.JFrame {
    
    private AccessCSVFile reader;  
    private ArrayList <Employee> empList = new ArrayList<>();

    /**
     * Creates new form GUISalaryCalculation
     */
    public GUISalaryCalculation() {
        initComponents();
    }

        @SuppressWarnings("unchecked")
        private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        salaryArea = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        backBtn = new javax.swing.JButton();
        showAllBtn = new javax.swing.JButton();
        idField = new javax.swing.JTextField();

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Calculate Employees Salary");

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jPanel2.setBackground(new java.awt.Color(204, 0, 153));

        salaryArea.setColumns(20);
        salaryArea.setRows(5);
        jScrollPane1.setViewportView(salaryArea);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addContainerGap())
        );

        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Times, New Roman", 1, 14)); 
        jLabel2.setText("Enter Employee ID:");

        backBtn.setFont(new java.awt.Font("Dialog", 1, 8)); 
        backBtn.setText("<<back");
        backBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtnActionPerformed(evt);
            }
        });

        showAllBtn.setText("Show all");
        showAllBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showAllBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(showAllBtn))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(backBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(showAllBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 10, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }
    private void backBtnActionPerformed(java.awt.event.ActionEvent evt) {        GUI gui = new GUI();
        gui.setVisible(true);
        this.setVisible(false);
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {        try {
            //Open File reader
            reader = new AccessCSVFile();
            reader.openFile();
            //Create instance of data structure:
            empList = reader.makeEmployeeArray();
            reader.closeFile();
            
            int index = -1;
            
            
            
            String id = idField.getText();
            
            for(int i = 0; i < empList.size(); i++) {
                if (empList.get(i).getEmpId().equals(id))
                    index = i;
            }
            
            if(index == -1) {salaryArea.setText("(Search returned no results)");}
            
            else
            {
                Employee emp = empList.get(index);
                
                salaryArea.setText("\n\n******************************************************\n");
                salaryArea.setText(salaryArea.getText()+"Employee ID: "+id+" Name: "+emp.getEmpName()+" "+emp.getEmpSurname()); 
                salaryArea.setText(salaryArea.getText()+"\n******************************************************\n"); 
                
                
                salaryArea.setText(salaryArea.getText()+"\nHours Worked\t\t\t"+emp.getEmpHoursWorked());
                salaryArea.setText(salaryArea.getText()+"\nRate of Pay\t\t\t"+"P"+String.format("%.2f",emp.getEmpPayRate()));
                salaryArea.setText(salaryArea.getText()+"\nBase Salary\t\t\t"+"P"+String.format("%.2f", emp.getEmpHoursWorked() * emp.getEmpPayRate()));
                
                salaryArea.setText(salaryArea.getText()+"\nCar Allowance\t\t\t"+"P"+String.format("%.2f",emp.getEmpHoursWorked() * emp.getEmpPayRate() * emp.getEmpCarAllowance()));
                
                
                salaryArea.setText(salaryArea.getText()+"\nMonthly Gratuity\t\t\t"+"P"+String.format("%.2f",emp.getEmpGratuity()));
                
                salaryArea.setText(salaryArea.getText()+"\n\nTotal Gross Salary\t\t"+"P"+String.format("%.2f",emp.calculateGrossSalary()));
                
                salaryArea.setText(salaryArea.getText()+"\n\nNet Salary (-15% tax)\t\t"+"P"+String.format("%.2f",emp.calculateNetSalary()));
                
            }
            
        } catch (IOException ex) {
            Logger.getLogger(GUISalaryCalculation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void showAllBtnActionPerformed(java.awt.event.ActionEvent evt) {
            salaryArea.setText("");
        salaryArea.setEditable(false);
        try {
            //Open File reader
            reader = new AccessCSVFile();
            reader.openFile();
            //Create instance of data structures:
            empList = reader.makeEmployeeArray();
            
            reader.closeFile();


            //Output search results:
            salaryArea.setText("*************************************************************************\n");
            salaryArea.setText(salaryArea.getText()+"ID\tName\tSurname\tGross Salary(BWP)\n");
            salaryArea.setText(salaryArea.getText()+"*************************************************************************\n");
            for(Employee emp: empList)
            {
                salaryArea.setText(salaryArea.getText()+emp.getEmpId()+"\t"+emp.getEmpName()+"\t"+emp.getEmpSurname()+"\t"+String.format("%.2f",emp.calculateGrossSalary())+"\n");
            }
            
            

        } catch (IOException ex) {
            Logger.getLogger(GUISalaryCalculation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }                                             

    private void backBtn2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        GUI gui = new GUI();
        gui.setVisible(true);
        this.setVisible(false);
    }                                        

    private void backBtn1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        GUI gui = new GUI();
        gui.setVisible(true);
        this.setVisible(false);
    }                                        

    private void searchGenderBtnActionPerformed(java.awt.event.ActionEvent evt) {                                                
        
    }
        public static void main(String args[]) {
                try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUISalaryCalculation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUISalaryCalculation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUISalaryCalculation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUISalaryCalculation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUISalaryCalculation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn;
    private javax.swing.JTextField idField;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea salaryArea;
    private javax.swing.JButton showAllBtn;
    // End of variables declaration//GEN-END:variables
}
