package detoursystem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * Author Fcse18-010
 */
public class AccessCSVFile {
    
    //Fields:
    private static final String FILE_NAME = "Employees.txt";
    private Scanner input;
    private File file;
    private String[] row;
    private Employee temp;
    
    private ArrayList <Employee> employeeList = new ArrayList<>();
    
    public void openFile() 
    {
        try {
            //Get the input file instance:
            file = new File(FILE_NAME);
            //Use Scanner to read file:
            input = new Scanner(file);
	} 
	catch (Exception e) {
		e.printStackTrace();
	} 
    }
    
    public ArrayList<Employee> makeEmployeeArray() throws IOException 
    {  
        
        while (input.hasNext()) { 
            
            String data = input.nextLine(); //Read row
            String[] row = data.split(","); //Specify separator
            
            temp = convertRowToObject(row);
            
            //Populate array with Employee object row:
            this.employeeList.add(temp);
        }
        return this.employeeList;
    }
    
    public Employee convertRowToObject(String[] row) {
        
        this.row = row;
        
        for(int i=1;i<this.row.length;i++) {
            //Get data:
            String department = this.row[8];
            String id = this.row[0];
            
                        if(department.equals("Accounts")){ //
                temp = new Accounts(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Human Resources")) {
                temp = new HumanResources(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Management")) {
                temp = new Management(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Marketing")) {
                temp = new Marketing(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else if(department.equals("Support")) {
                temp = new Support(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }else {
                temp = new Temporary(row[0],row[1],row[2],row[3].charAt(0),row[4],row[5],row[6],row[7],row[8],row[9],Integer.parseInt(row[10]),Double.parseDouble(row[11]),Integer.parseInt(row[12]),Double.parseDouble(row[13]),Double.parseDouble(row[14]));
            }
        }
        return temp;
    }
    
    public void closeFile() throws IOException {input.close();}
   
    
}
