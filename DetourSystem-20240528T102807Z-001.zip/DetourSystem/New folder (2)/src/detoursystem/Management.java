package detoursystem;

/**
 *
 * Author Fcse18-010 */
public class Management extends Employee {

        public Management(String empId, String empName, String empSurname, char empGender, String empDob, String empAddress, String city, String empTitle, String empHireDate, String department, int empHoursWorked, double empPayRate, int empLeaveDays, double empGratuity, double empCarAllowance) {
        super(empId, empName, empSurname, empGender, empDob, empAddress, city, empTitle, empHireDate, department, empHoursWorked, empPayRate, empLeaveDays, empGratuity, empCarAllowance);
    }

    @Override
    public double calculatCarAllowance() {return this.empCarAllowance * this.empHoursWorked * this.empPayRate;}

    @Override
    public double calculateGrossSalary() {return (1 + this.empCarAllowance) * this.empHoursWorked * this.empPayRate;}

    @Override
    public double calculateNetSalary() {return ((1 + this.empCarAllowance) * this.empHoursWorked * this.empLeaveDays) * (1 - Employee.TAX_RATE);}
    
}
