package detoursystem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * Author Fcse18-010
 */
public class GUISearch extends javax.swing.JFrame {
    
    private AccessCSVFile reader;  
    private ArrayList <Employee> empList;
    private ArrayList <Employee> searchResults;
    private Search find;
    private char searchGender;
    private String searchCity;

    /**
     * Creates new form GUISearch
     */
    public GUISearch() {
        initComponents();
    }

        @SuppressWarnings("unchecked")
        private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        genderArea = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        maleRadioBtn = new javax.swing.JRadioButton();
        femaleRadioBtn = new javax.swing.JRadioButton();
        jLabel5 = new javax.swing.JLabel();
        searchGenderBtn = new javax.swing.JButton();
        backBtn1 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        cityArea = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        cityField = new javax.swing.JTextField();
        searchCityBtn = new javax.swing.JButton();
        backBtn2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));

        genderArea.setColumns(20);
        genderArea.setRows(5);
        jScrollPane3.setViewportView(genderArea);

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); 
        jLabel4.setText("Select Gender:");

        buttonGroup1.add(maleRadioBtn);
        maleRadioBtn.setText("Male");

        buttonGroup1.add(femaleRadioBtn);
        femaleRadioBtn.setText("Female");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); 
        jLabel5.setText("Search Results:");

        searchGenderBtn.setText("Search");
        searchGenderBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchGenderBtnActionPerformed(evt);
            }
        });

        backBtn1.setFont(new java.awt.Font("Dialog", 1, 8)); 
        backBtn1.setText("<<back");
        backBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtn1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel5)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(femaleRadioBtn)
                            .addComponent(searchGenderBtn)
                            .addComponent(maleRadioBtn))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(backBtn1))
                        .addContainerGap(98, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 14, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(backBtn1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(maleRadioBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(femaleRadioBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(searchGenderBtn)
                        .addContainerGap())
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jTabbedPane1.addTab("Search by Gender", jPanel4);

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); 
        jLabel6.setText("Search Results:");

        cityArea.setColumns(20);
        cityArea.setRows(5);
        jScrollPane4.setViewportView(cityArea);

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); 
        jLabel3.setText("Enter City:");

        searchCityBtn.setText("Search");
        searchCityBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchCityBtnActionPerformed(evt);
            }
        });

        backBtn2.setFont(new java.awt.Font("Arial", 1, 18)); 
        backBtn2.setText("<<back");
        backBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backBtn2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(cityField, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchCityBtn)
                            .addComponent(backBtn2)))
                    .addComponent(jLabel6))
                .addContainerGap(81, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 14, Short.MAX_VALUE)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(backBtn2)
                        .addGap(289, 289, 289)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cityField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(searchCityBtn)
                        .addContainerGap())
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        jTabbedPane1.addTab("Search by City/Town", jPanel5);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }
    private void searchCityBtnActionPerformed(java.awt.event.ActionEvent evt) {
        cityArea.setText("enter city");
        cityArea.setEditable(false);
        try {
            //Open File reader
            reader = new AccessCSVFile();
            reader.openFile();
            //Create instance of data structures:
            empList = reader.makeEmployeeArray();
            searchResults = new ArrayList<>();
            
            reader.closeFile();

            searchCity = cityField.getText();
            //Create search object to retrieve data:
            find = new Search();
            
            if(!searchCity.equals("")) {
                //Retrieve results of city entered:
                searchResults = find.searchCity(searchCity, empList, searchResults);

                //Output search results:
                cityArea.setText("****************************************************************\n");
                cityArea.setText(cityArea.getText()+"ID\tName\tSurname\tCity\n");
                cityArea.setText(cityArea.getText()+"****************************************************************\n");
                for(Employee emp: searchResults)
                {
                    cityArea.setText(cityArea.getText()+emp.getEmpId()+"\t"+emp.getEmpName()+"\t"+emp.getEmpSurname()+"\t"+emp.getCity()+"\n");
                }
            }else {
                cityArea.setText("Please enter a Town/City name and try again.");
            }
            

        } catch (IOException ex) {
            Logger.getLogger(GUISalaryCalculation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void backBtn2ActionPerformed(java.awt.event.ActionEvent evt) {
            GUI gui = new GUI();
        gui.setVisible(true);
        this.setVisible(false);
    }
    private void backBtn1ActionPerformed(java.awt.event.ActionEvent evt) {
            gui.setVisible(true);
        this.setVisible(false);
    }
    private void searchGenderBtnActionPerformed(java.awt.event.ActionEvent evt) {
            cityArea.setText("");
        cityArea.setEditable(false);
        try {
            //Open File reader
            reader = new AccessCSVFile();
            reader.openFile();
            //Create instance of data structures:
            empList = reader.makeEmployeeArray();
            searchResults = new ArrayList<>();
            
            reader.closeFile();
            
            searchGender = '.';
            
            if(maleRadioBtn.isSelected()) {searchGender = 'M';}
            else if(femaleRadioBtn.isSelected()) {searchGender = 'F';}

            //Create search object to retrieve data:
            find = new Search();
            
            if(searchGender!='.') {
                //Retrieve results of city entered:
                searchResults = find.searchGender(searchGender, empList, searchResults);

                //Output search results:
                genderArea.setText("****************************************************************\n");
                genderArea.setText(genderArea.getText()+"ID\tName\tSurname\tGender\n");
                genderArea.setText(genderArea.getText()+"****************************************************************\n");
                for(Employee emp: searchResults)
                {
                    genderArea.setText(genderArea.getText()+emp.getEmpId()+"\t"+emp.getEmpName()+"\t"+emp.getEmpSurname()+"\t"+emp.getEmpGender()+"\n");
                }
            }else {
                genderArea.setText("Please select a gender and proceed to search.");
            }
            

        } catch (IOException ex) {
            Logger.getLogger(GUISalaryCalculation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void main(String args[]) {
                try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUISearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUISearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUISearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUISearch.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUISearch().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backBtn1;
    private javax.swing.JButton backBtn2;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextArea cityArea;
    private javax.swing.JTextField cityField;
    private javax.swing.JRadioButton femaleRadioBtn;
    private javax.swing.JTextArea genderArea;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JRadioButton maleRadioBtn;
    private javax.swing.JButton searchCityBtn;
    private javax.swing.JButton searchGenderBtn;
    // End of variables declaration//GEN-END:variables
}
